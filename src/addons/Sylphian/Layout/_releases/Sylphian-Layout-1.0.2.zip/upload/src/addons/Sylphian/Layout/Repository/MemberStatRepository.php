<?php

namespace Sylphian\Layout\Repository;

use XF\Repository\MemberStatRepository as XFMemberController;

class MemberStatRepository extends XFMemberController
{
    protected function prepareCacheResults($order, array $cacheResults)
    {
        switch ($order)
        {
            case 'reaction_score':
            case 'message_count':
            case 'trophy_points':
                $cacheResults = array_map(function ($value)
                {
                    return \XF::language()->numberFormat($value);
                }, $cacheResults);
                break;

            case 'register_date':
            case 'last_activity':
                $cacheResults = array_map(function ($value)
                {
                    return \XF::language()->date($value);
                }, $cacheResults);
                break;
        }

        $this->app->fire('member_stat_result_prepare', [$order, &$cacheResults]);

        return $cacheResults;
    }
}